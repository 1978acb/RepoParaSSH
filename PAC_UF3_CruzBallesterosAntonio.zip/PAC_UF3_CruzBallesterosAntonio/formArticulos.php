<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Formulario de artículos</title>
</head>
<body>

	<?php 
	
		include "funciones.php";
		
		// Comprobar si el usuario tiene permisos
		$tipoUsuario = isset($_COOKIE['tipo_usuario']) ? $_COOKIE['tipo_usuario'] : '';
		if ($tipoUsuario != 'superadmin' && $tipoUsuario != 'usuario_autorizado') {
			// Redirigir a la página de acceso si no tiene permisos
			header("Location: index.php");
			exit();
		}
		
		if (isset ($_GET ['editar'])){
			$id = $_GET ['editar'];
			//A través del ID los datos del Producto
			$datos = mysqli_fetch_assoc(getProducto ($id));
			echo $datos['Name'];
			echo "<h2>Editar</h2>";
		}elseif{
			if (isset ($_GET ['editar'])){
			$id = $_GET ['editar'];
			//A través del ID los datos del Producto
			$datos = mysqli_fetch_assoc(getProducto ($id));
			echo $datos['Name'];
			echo "<h2>Editar</h2>";
		}elseif{
			if (isset ($_GET ['borrar'])){
			$id = $_GET ['borrar'];
			//A través del ID los datos del Producto
			$datos = mysqli_fetch_assoc(getProducto ($id));
			echo $datos['Name'];
			echo "<h2>Borrar</h2>";
		}
		
	?>
		
		<form action="fomArticulos.php" method="POST">
		
			<h2>Añadir Producto</h2>
	
				<label for="nombre">Nombre:</label>
				<input type="text" name="nombre" value="<?php echo $nombre; ?>" required><br>

				<label for="coste">Coste:</label>
				<input type="number" name="coste" value="<?php echo $coste; ?>" required><br>

				<label for="precio">Precio:</label>
				<input type="number" name="precio" value="<?php echo $precio; ?>" required><br>

				<label for="categoria">Categoría:</label>
					<select name="categoria">
					<?php
					// Obtener y mostrar las opciones de categoría
					$categorias = getCategorias();
					foreach ($categorias as $categoriaItem) {
						echo '<option value="' . $categoriaItem['CategoryID'] . '">' . $categoriaItem['Name'] . '</option>';
					}
					?>
				</select><br>

				<button type="submit">Añadir</button>
		
			<h2>Editar Producto</h2>


				<input type="hidden" name="idProducto" value="<?php echo $idProducto; ?>">

				<label for="nombre">Nombre:</label>
				<input type="text" name="nombre" value="<?php echo $nombre; ?>" required><br>

				<label for="coste">Coste:</label>
				<input type="number" name="coste" value="<?php echo $coste; ?>" required><br>

				<label for="precio">Precio:</label>
				<input type="number" name="precio" value="<?php echo $precio; ?>" required><br>

				<label for="categoria">Categoría:</label>
				<select name="categoria">
					<?php
					// Obtener y mostrar las opciones de categoría
					$categorias = getCategorias();
					foreach ($categorias as $categoriaItem) {
						$selected = ($categoriaItem['CategoryID'] == $categoria) ? 'selected' : '';
						echo '<option value="' . $categoriaItem['CategoryID'] . '" ' . $selected . '>' . $categoriaItem['Name'] . '</option>';
					}
					?>
				</select><br>

				<button type="submit">Editar</button>
				
			
			<h2>Borrar Producto</h2>
			
				<input type="hidden" name="idProducto" value="<?php echo $idProducto; ?>">

				<p>¿Está seguro de que desea borrar el siguiente producto?</p>
				<ul>
					<li><strong>ID:</strong> <?php echo $idProducto; ?></li>
					<li><strong>Nombre:</strong> <?php echo $nombre; ?></li>
					<li><strong>Coste:</strong> <?php echo $coste; ?></li>
					<li><strong>Precio:</strong> <?php echo $precio; ?></li>
					<li><strong>Categoría:</strong> <?php echo $categoria; ?></li>
				</ul>

				<button type="submit" name="confirmarBorrar">Borrar</button>
				
			
			<?php
				// Enlace para volver a la página de productos
				echo '<p><a href="articulos.php">Volver a Productos</a></p>';
			?>
		</form>
	
</body>
</html>