<?php 

	function crearConexion() {
		// Cambiar en el caso en que se monte la base de datos en otro lugar
		$host = "localhost";
		$user = "root";
		$pass = "";
		$baseDatos = "pac3_daw";

		// Completar...
		
		// Conectamos con la base de datos
		$conexion = mysqli_connect ($host, $user, $pass, $baseDatos);
		
		// Mensaje de error si falla la conexión
		if (!$conexion){
			die("<br>Falló la conexión a la base de datos " . mysqli_connect_error());
		}
		//Si no hay error de conexión 
		else{
			echo "<br>Establecida la conexión a la base de datos " . $baseDatos;
		}
		return $conexion;	
	}


	function cerrarConexion($conexion) {
		// Completar...
		mysqli_close($conexion);
	}


?>