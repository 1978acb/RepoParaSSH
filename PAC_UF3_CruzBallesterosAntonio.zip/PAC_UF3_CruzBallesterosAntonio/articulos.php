<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Articulos</title>
</head>
<body>

	<?php 

		include "funciones.php";
		
		pintaCategorias($defecto);
		pintaTablaUsuarios();
		pintaProductos($orden);
		

	?>

	<h1>Lista de artículos</h1>

</body>
</html>