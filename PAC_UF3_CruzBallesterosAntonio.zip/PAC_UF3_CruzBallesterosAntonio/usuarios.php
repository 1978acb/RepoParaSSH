<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="estilo.css">
	<title>Usuarios</title>
</head>
<body>

	<?php 

		include "funciones.php";
	
		// Comprobar si el usuario tiene permisos suficientes
		if (!tienePermisosSuficientes()) {
			echo "No tienes permisos para acceder a esta página.";
			exit;
		}

		// Obtener y mostrar el valor actual de los permisos
		$permisosActuales = getPermisos();
		echo "<p>Permisos actuales de la aplicación: $permisosActuales</p>";

		// Botón para cambiar los permisos
		echo '<form method="post" action="cambiarPermisos.php">';
		echo '<button type="submit" name="cambiarPermisos">Cambiar Permisos</button>';
		echo '</form>';

		// Mostrar la tabla de usuarios
		echo '<h2>Listado de Usuarios</h2>';
		echo '<table border="1">';
		echo '<tr><th>Nombre</th><th>Email</th><th>Autorizado</th></tr>';

		$usuarios = getListaUsuarios();

		foreach ($usuarios as $usuario) {
			$nombre = $usuario['FullName'];
			$correo = $usuario['Email'];
			$autenticacion = $usuario['Enabled'];

			// Cambiar el color de fondo para usuarios autorizados
			$claseCss = ($autenticacion == 1) ? 'autorizado' : '';

			echo "<tr class='$claseCss'><td>$nombre</td><td>$email</td><td>$autorizado</td></tr>";
		}

		echo '</table>';

		// Enlace para volver a index.php
		echo '<p><a href="index.php">Volver a Inicio</a></p>';
	?>

</body>
</html>