<?php 

	include "conexion.php";

	function tipoUsuario($nombre, $correo){
		// Completar...
		
		//Conexión a la base de datos
		$DB = crearConexion("pac3_daw");
		
		 
		/* if($_SERVER['REQUEST_METHOD'])=== 'POST'){
			 $nombre  = $_POST['FullName'];
			 $correo  = $_POST['Email'];
			 */
			 
			 
		$consulta = $conexion->prepare("SELECT * FROM user WHERE FullName = ? AND Email = ?");
		$consulta->bind_param("ss", $nombre, $correo);
		$consulta->execute();

		$resultado = $consulta->get_result();
			 
			 
			 
		//Validación
		/*	switch($nombre, $correo){
				case "superadmin":
					return "Hola Superadmin, $nombre. Correo: $correo. <a href='usuarios.php'>Acceder a usuarios</a>";
				case "usuario_autorizado":
					return "Hola Usuario Autorizado, $nombre. Correo: $correo. <a href='articulos.php'>Acceder a artículos</a>";
				case "usuario_registrado":
					return "Hola Usuario Registrado, $nombre. Correo: $correo. No tienes permisos para acceder.";
				case "registrado_no_autorizado":
					return "Hola Usuario Registrado, $nombre. Correo: $correo. No tienes permisos para acceder."
				default:
					return "Usuario no registrado.";
				}
		 }
		 cerrarConexion($DB);*/
		 
		 if ($resultado->num_rows > 0) {
					$usuario = $resultado->fetch_assoc();

					if ($usuario['Enabled'] == 1) {
						cerrarConexion($conexion);
						return "autorizado";
					} else {
						cerrarConexion($conexion);
						return "registrado";
					} 
				}else {
						cerrarConexion($conexion);
						return "no registrado";
				}
			
		 
	}
	


	function esSuperadmin($nombre, $correo){
		// Completar...
		
		//Conexión a la base de datos
		$DB = crearConexion("pac3_daw");
		
		
		if($host == 3){
			echo "True";
		}else{
			echo "False";
		}
		$resultado = mysqli_query($DB, $sql);
		cerrarConexion($DB);
		 
	}


	function getPermisos() {
		// Completar...
		
		//Conexión a la base de datos
		$DB = crearConexion("pac3_daw");
		
		  // Consulta SQL para obtener el valor de la columna Autenticacion de la tabla setup
		$sql = "SELECT Autenticacion FROM setup";
		$resultado = mysqli_query($DB, $sql);

		 // Comprobar si hay resultados
		if ($resultado->num_rows > 0) {
         // Obtener el valor de Autenticacion
			$fila = $resultado->fetch_assoc();
			$autenticacion = $fila['Autenticación'];

         // Cerrar el resultado
			$resultado->close();

         // Devolver el valor de Autenticacion
			return $autenticacion;
        }else {
         // No hay resultados
			return "No se encontraron datos en la tabla 'setup'";
        }
		cerrarConexion($DB);
	}


	function cambiarPermisos() {
		// Completar...	
		
		//Conexión a la base de datos
		$DB = crearConexion("pac3_daw");
		
		// Consulta SQL para cambiar el valor de Autenticacion en la tabla setup
		$sql = "UPDATE setup SET Autenticacion = CASE WHEN Autenticacion = 0 THEN 1 ELSE 0 END WHERE Autenticacion IN (0, 1)";
		$resultado = mysqli_query($DB, $sql);

		if ($resultado === TRUE) {
			echo "Valor de Autenticacion actualizado correctamente.";
		} else {
			echo "Error al actualizar el valor de Autenticacion. ";
		}
		cerrarConexion($DB);
	}


	function getCategorias() {
		// Completar...	
		
		//Conexión a la base de datos
		$DB = crearConexion("pac3_daw");
		
		// Consulta SQL para obtener los datos de CategoryID y Name de la tabla category
		$sql = "SELECT CategoryID, Name FROM category";
		$resultado = mysqli_query($DB, $sql);
		cerrarConexion($DB);
	}


	function getListaUsuarios() {
		// Completar...	
		
		//Conexión a la base de datos
		$DB = crearConexion("pac3_daw");
		
		
		// Consulta SQL para obtener los datos de todos los usuarios
		$sql = "SELECT FullName, Email, Enabled FROM user";
		$resultado = mysqli_query($DB, $sql);

		// Comprobar si hay resultados
		if ($resultado->num_rows > 0) {
			return $resultado;
        }else {
       // No hay resultados
            echo "No se encontraron usuarios en la tabla 'user'.";
        }
		cerrarConexion($DB);
	}


	function getProducto($ID) {
		// Completar...	
		
		//Conexión a la base de datos
		$DB = crearConexion("pac3_daw");
		
		
		// Consulta SQL para obtener los datos del producto por su ID
		$sql = "SELECT * FROM product WHERE ID = $ID";
		$resultado = mysqli_query($DB, $sql);
		
		cerrarConexion($DB);
		
	}


	function getProductos($orden) {
		// Completar...	
		
		//Conexión a la base de datos
		$DB = crearConexion("pac3_daw");
		
		$sql = "SELECT product.ProductID, product.Name, product.Cost, product.Price, category.Name AS CategoryName
            FROM product
            INNER JOIN category ON product.CategoryID = category.CategoryID
            ORDER BY $orden";

		$resultado = mysqli_query($DB, $sql);
		
		cerrarConexion($DB);
	}


	function anadirProducto($nombre, $coste, $precio, $categoria) {
		// Completar...	
		
		//Conexión a la base de datos
		$DB = crearConexion("pac3_daw");
		
		$sql = "INSERT INTO product (Name, Cost, Price, CategoryID)
            VALUES ('$nombre', $coste, $precio, $categoria)";

		// Ejecutar la consulta
		if (mysqli_query($DB, $sql) === TRUE) {
			return "Producto añadido correctamente.";
		} else {
			return "Error al añadir el producto: " . $conexion;
		}
		cerrarConexion($DB);
	}


	function borrarProducto($id) {
		// Completar...

		//Conexión a la base de datos
		$DB = crearConexion("pac3_daw");
		
		// Consulta SQL para borrar el producto por su ID
		$sql = "DELETE FROM productos WHERE ProductID = $id";

		// Ejecutar la consulta
		if (mysqli_query($DB, $sql) === TRUE) {
			return "Producto eliminado correctamente.";
		} else {
			return "Error al eliminar el producto: " . $conexion;
		}
		
		cerrarConexion($DB);
	}


	function editarProducto($id, $nombre, $coste, $precio, $categoria) {
		// Completar...	
		
		//Conexión a la base de datos
		$DB = crearConexion("pac3_daw");
		
		 // Consulta SQL para actualizar la información del producto por su ID
		$sql = "UPDATE productos
            SET Name = '$nombre', Cost = $coste, Price = $precio, CategoryID = $categoria
            WHERE ProductID = $id";

		// Ejecutar la consulta
		if (mysqli_query($DB, $sql) === TRUE) {
			return "Producto actualizado correctamente.";
		} else {
			return "Error al actualizar el producto: " . $conexion;
		}
		
		cerrarConexion($DB);
		}

?>