<?php 

	include "consultas.php";


	function pintaCategorias($defecto) {
		// Completar...	
		//Mensaje de error
		$datos_categorias  = getCategorias();
		if(is_string($datos_categorias){
			echo $datos_categorias;
		// Recibiendo los datos
		}else{
			echo "<table>\n
					<tr>\
						<th>CategoryID</th>\n
						<th>Name</th>\n
					</tr>\n";
			}
		if  ($fila = mysqli_fetch_assoc($datos_categorias)) {
			echo "<tr>\n
					<td>" . $fila["CategoryID"] . "</td>\n
					<td>" . $fila["Name"] . "</td>\n
				 </tr>";
			echo "</table>";
			
		}else{
			echo $defecto . "</table>";
		}
		
		
		
	}
	

	function pintaTablaUsuarios(){
		// Completar...	
		
		$datos_usuarios  = getListaUsuarios();
		if(is_string($datos_usuarios){
			echo $datos_usuarios;
		// Recibiendo los datos
		}else{
			echo "<table>\n
					<tr>\
						<th>FullName</th>\n
						<th>Email</th>\n
						<th>Enabled</th>\n
					</tr>\n";
			}
		while  ($fila = mysqli_fetch_assoc($datos_usuarios)) {
			if ($fila = Enabled == 1) {
				echo "<tr class='rojo'>\n";
			}else{
				echo"<tr>\n"
			}
		};
	}

		
	function pintaProductos($orden) {
		// Completar...	
		
		$datos_productos  = getProducto();
		if(is_string($datos_productos){
			echo $datos_productos;
		// Recibiendo los datos
		}else{
			echo "<table>\n
					<tr>\
						<th>ProductID</th>\n
						<th>Name</th>\n
						<th>Cost</th>\n
						<th>Price</th>\n
						<th>CategoryID</th>\n
						
					</tr>\n";
			}
		while  ($fila = mysqli_fetch_assoc($datos_productos)) {
			echo "<tr>\n
					<td>" . $fila["ProductID"] . "</td>\n
					<td>" . $fila["Name"] . "</td>\n
					<td>" . $fila["Cost"] . "</td>\n
					<td>" . $fila["Price"] . "</td>\n
					<td>" . $fila["CategoryID"] . "</td>\n
				 </tr>";
	    };
			echo "</table>";
		
		
		if(isset ($_POST['borrar'])){
			$borrarProducto ($_POST["ProductID"]);
		}
		if(isset ($_POST['editar'])){
			$editarProducto ($_POST["ProductID"]);
		}
		
		
		if (!isset ($_GET['ordenar'])){
			$ordenar="Creciente";
		}else{
			$ordenar = $_GET['ordenar'];
		}
		
			echo '<a href="formArticulo.php?id=' . $producto['ProductID'] . '">Editar</a>';
            echo ' | ';
            echo '<a href="consultas.php?action=borrar&id=' . $producto['ProductID'] . '">Borrar</a>';
		
    }

?>